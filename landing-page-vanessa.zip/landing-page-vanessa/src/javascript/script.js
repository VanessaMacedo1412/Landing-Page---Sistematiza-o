$(document).ready(function () {
    // Inicialmente, esconda o formulário
    $('#formularioContato').hide();

    // Função para abrir o formulário
    $('#botaoContato').on('click', function () {
        $('#formularioContato').fadeIn();
    });

    // Função para fechar o formulário ao clicar no botão de fechar
    $('#botaoFecharFormulario').on('click', function () {
        $('#formularioContato').fadeOut();
    });

    // Função para fechar o formulário ao clicar fora dele
    $(window).on('click', function (e) {
        if ($(e.target).is('#formularioContato')) {
            $('#formularioContato').fadeOut();
        }
    });
});
